#!/usr/bin/env python3
import rclpy
import math
from rclpy.node import Node

from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from unmanned_systems_ros2_pkg import quaternion_tools
#need to import the correct datatype and topic for odom position data

class movementClass(Node):

    def __init__(self,ns = ''):
        super().__init__('hw4_3Node')
        if ns != '':#set up namespace
            self.ns = ns
        else:
            self.ns = ns
        self.cmdPub = self.create_publisher(Twist, self.ns +'/cmd_vel', 10)

        self.moveProcedure()
     
    def listener_callback(self, msg):
        self.get_logger().info('I heard: "%s"' % msg.data)
               
    def rotate(self):
        msg = Twist()
        msg.angular.z = -0.15
        msg.linear.x = 0.0
        self.cmdPub.publish(msg)

    def fullStop(self):
        msg = Twist()
        msg.angular.z = 0.0
        msg.linear.x = 0.0
        self.cmdPub.publish(msg)

    def moveProcedure(self):
        self.move_forward()
        self.sleepSecs(5)
        self.fullStop()
        self.rotate()
        self.sleepSecs(2)
        self.fullStop()
        self.move_forward()
        self.sleepSecs(5)
        self.fullStop()

    def sleepSecs(self,duration):#a very crude blocking timer...
        duration = rclpy.time.Duration(seconds=duration)
        start = self.get_clock().now()
        while self.get_clock().now() - start < duration:
            pass
    		
    def move_forward(self):
        msg = Twist()
        msg.linear.x = 1.5
        msg.angular.z = 0.0
        self.cmdPub.publish(msg)


def main(args=None):
    rclpy.init(args=args)

    move = movementClass()

    rclpy.spin(move)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    move.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
