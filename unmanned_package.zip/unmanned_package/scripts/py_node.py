#!/usr/bin/env python3
#be sure to include the above "shebang"
import rclpy
from rclpy.node import Node

from std_msgs.msg import String
from unmanned_package.lab_python_module import print_hello

"""IMPORT OUR PYTHON MODULE"""
#from unmanned_package.lab_python_module import print_hello

class MinimalPublisher(Node):

    def __init__(self):
        super().__init__('minimal_publisher')
        self.publisher_ = self.create_publisher(String, 'topic', 10)
        timer_period = 0.5  # seconds
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.i = 0

    def timer_callback(self):
        msg = String()
        msg.data = 'Hello World: %d' % self.i
        self.publisher_.publish(msg)
        self.get_logger().info('Publishing: "%s"' % msg.data)
        self.i += 1


def main(args=None):
    rclpy.init(args=args)#initiate the node into the ros framework

    minimal_publisher = MinimalPublisher()
    #create a custom node class, inheriting from ros's node class

    rclpy.spin(minimal_publisher)
    #continuously loops the publisher
    """
    node typically runs 1 script
    "launch" allows multiple nodes to be executed at once
    
    """
    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    minimal_publisher.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    print_hello()
    main()