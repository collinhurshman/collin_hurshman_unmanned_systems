#!/usr/bin/env python3
from cmath import pi
from socket import MSG_DONTROUTE
from sre_constants import AT_BEGINNING
from turtle import heading
import rclpy
import math
from unmanned_package import PIDSignal
from unmanned_package.pathFinding import rrtPath
from unmanned_package.pathFinding import dijkstra
from unmanned_package.pathFinding import aStar
from rclpy.node import Node
import time

from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from unmanned_package.timing import getTimeInSeconds
from unmanned_systems_ros2_pkg import quaternion_tools
#need to import the correct datatype and topic for odom position data

class setHeading(Node):

    def __init__(self,ns = ''):
        super().__init__('hw4_3Node')
        if ns != '':#set up namespace
            self.ns = ns
        else:
            self.ns = ns
        self.currentHeading = 0.0
        self.cmdPub = self.create_publisher(Twist, self.ns +'/cmd_vel', 10)
        self.odom_subscriber = self.create_subscription(
			Odometry, self.ns +"/odom", self.odom_callback, 10)

    def odom_callback(self,msg):
        """subscribe to odometry"""	
        self.currentX = msg.pose.pose.position.x
        self.currentY = msg.pose.pose.position.y
        qx = msg.pose.pose.orientation.x
        qy = msg.pose.pose.orientation.y
        qz = msg.pose.pose.orientation.z
        qw = msg.pose.pose.orientation.w
        roll,pitch,yaw = quaternion_tools.euler_from_quaternion(qx, qy, qz, qw)

        self.currentHeading = yaw*180/pi #conversion to degrees...

    def publishHeading(self,AngVelCMD):
        #if abs(AngVelCMD) > 0.15:#enforce max speed(extremely slow)
            #AngVelCMD = abs(AngVelCMD)*0.15/(AngVelCMD)
        msg = Twist()
        msg.angular.z = AngVelCMD
        msg.linear.x = 0.20
        self.cmdPub.publish(msg)

def distance(pos1,pos2):
    dist = math.sqrt((pos1[0] - pos2[0])**2 + (pos1[1] - pos2[1])**2)
    return dist

def main(args=None):
    rclpy.init(args=args)
    headingNode = setHeading()
    setPoint = 90.
    dt = rclpy.time.Duration(seconds=0.010)
    PID = PIDSignal.PIDSignal(.05,0.001,0.0015,0.01)

    myGrid = rrtPath.Grid(15,15,0.5)
    startCoords = (1,1)
    endCoords = (7,13)
    obsX = [2, 2, 2, 2, 0, 1, 2, 3, 4, 5, 5, 5, 5, 5, 8, 9, 10, 11, 12, 13, 8, 8, 8, 8, 8, 8, 8, 2, 3, 4, 5, 6, 7, 
9, 10, 11, 12, 13, 14, 15, 2, 2, 2, 2, 2, 2, 5, 5, 5, 5, 5, 5, 5, 6, 7, 8, 9, 10, 11, 12, 12, 12, 12, 12]
    obsY = [2, 3, 4, 5, 5, 5, 5, 5, 5, 5, 2, 3, 4, 5, 2, 2, 2, 2, 2, 2, 3, 4, 5, 6, 7, 8, 9, 7, 7, 7, 7, 7, 7, 6, 6, 6, 
6, 6, 6, 6, 8, 9, 10, 11, 12, 13, 9, 10, 11, 12, 13, 14, 15, 12, 12, 12, 12, 12, 12, 8, 9, 10, 11, 12]
    obsCoords = []
    for i in range(0,len(obsX)):
        obsCoords.append([obsX[i],obsY[i]])
    #dkPathFinder = dijkstra.DijkstraPath(myGrid,obsCoords,startCoords,endCoords,0.5)
    rrt = rrtPath.rrtPath(myGrid,obsCoords,startCoords,endCoords,0.49)
    #asT = aStar.aStarPath(myGrid,obsCoords,startCoords,endCoords,0.49)
    print("Searching for valid path...")
    startTime = time.time()
    #dkPathFinder.findPath()
    rrt.findPath()
    #asT.findPath()
    endTime = time.time()
    print("Found a path in ",endTime-startTime , " seconds")
    
    rrt.showBaseGrid()
    rrt.showPlots()

    startTime = getTimeInSeconds(headingNode)
    rclpy.spin_once(headingNode)
    for point in rrt.path:
        print("Proceeding towards:", point)

        #deltaX = point[0] - headingNode.currentX
        #deltaY = point[1] - headingNode.currentY
        #setPoint = math.atan2(deltaY,deltaX)*180/pi
        #print(setPoint)
        while distance(point,[headingNode.currentX,headingNode.currentY]) >= 0.1:
            #while far from the way point, head toward it...
            rclpy.spin_once(headingNode)
            deltaX = point[0] - headingNode.currentX
            deltaY = point[1] - headingNode.currentY
            setPoint = math.atan2(deltaY,deltaX)*180/pi
            if setPoint < 0:
                setPoint = setPoint +360
                #this can help reduce flip-flopping between -180 and 180 degree headings...
                #which actually mean the same thing
            fullHeading = headingNode.currentHeading
            if fullHeading < 0:
                fullHeading = fullHeading +360
            error = setPoint - fullHeading
            if 360 - abs(error) < abs(error):#decide which direction is faster to go in
                error = -abs(error)*(360-abs(error))/error
            if abs(error)>2:
                yawVelCMD = float(PID.computeSignal(error))
                headingNode.publishHeading(yawVelCMD)
                #block for dt...may not be the best for callbacks.. keep dt low..
                start = headingNode.get_clock().now()
                while headingNode.get_clock().now() - start < dt:
                    pass
            else:
            #now drive straight forward
                msg = Twist()
                msg.angular.z=0.
                msg.linear.x = 0.20
                headingNode.cmdPub.publish(msg)
    endTime = getTimeInSeconds(headingNode)
    print("Followed the path in ",endTime-startTime , " seconds")            
    #note...the loop runs again in the rclpy.ok loop to ensure it hasn't drifted past
    msg = Twist()
    msg.angular.z=0.
    msg.linear.x = 0.0
    headingNode.cmdPub.publish(msg)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    headingNode.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
