#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from unmanned_package import timing
from geometry_msgs.msg import Twist # import package containing the...
#...input command type used when publishing to cmd_vel

"""
Goals:
    turn bot1 for 0 to 5
    turn bot2 for 5 to 10 seconds
"""
"""
Setup steps:
    initialize main func
    create ros node
    initiate the node
    instantiate the node
    implement the algorithm
"""
class TurtleBotNode(Node):#this node inherits from the base node class
    def __init__(self, node_name, botName=""):
        if node_name == "":#ros requires a nonempty name for the node
            node_name = "unnamedNode"

        super().__init__(node_name)#call the parent node class' init function
        #create a publisher in order to update the cmd_vel topic
        self.cmd_pub = self.create_publisher(Twist, botName + "/cmd_vel",10) #publishing Twist messages to the cmd_vel topic...
        #... with at most 10 msgs held in the queue

    def move_turtlebot(self, linear_vel,ang_vel):
        someTwist = Twist()
        someTwist.linear.x = linear_vel
        someTwist.angular.z = ang_vel
        self.cmd_pub.publish(someTwist)

def main():
    #location main subroutine is run from...
    #initiate the node in the ros2 framework
    rclpy.init(args= None)
    turtlebot_node = TurtleBotNode("bot1Node","")
    turtlebot_2_node = TurtleBotNode("bot2Node","turtle")
    zerotime = timing.getTimeInSeconds(turtlebot_node)#take note of the start time
    firstBotTime = 5
    secondBotTime = 10
    while rclpy.ok():#while everything is good... keep looping 
        time_now = timing.getTimeInSeconds(turtlebot_node)
        if time_now - zerotime <= firstBotTime:#0 to 5 second interval
            turtlebot_node.move_turtlebot(0.,0.25)#rotate  
        elif time_now - zerotime >= firstBotTime and time_now - zerotime <= secondBotTime:
            #5 to 10 second interval
            #move second bot, stop first bot
            turtlebot_2_node.move_turtlebot(0.0,0.25)
            turtlebot_node.move_turtlebot(0.0,0.)            
        else:
            #make certain BOTH bots have stopped after time interval...
            turtlebot_2_node.move_turtlebot(0.0,0.0)
            turtlebot_node.move_turtlebot(0.0,0.)##pass in 0 velocity and angular vel, respectively
            rclpy.shutdown()#end the node when rotation is stopped
    #note no call to spin is needed since there are no callbacks yet...
        

if __name__ == '__main__':
    main()