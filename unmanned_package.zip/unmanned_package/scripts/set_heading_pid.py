#!/usr/bin/env python3
from cmath import pi
from sre_constants import AT_BEGINNING
from turtle import heading
import rclpy
import math
from unmanned_package import PIDSignal
from rclpy.node import Node

from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from unmanned_systems_ros2_pkg import quaternion_tools
#need to import the correct datatype and topic for odom position data

class setHeading(Node):

    def __init__(self,ns = ''):
        super().__init__('hw4_3Node')
        if ns != '':#set up namespace
            self.ns = ns
        else:
            self.ns = ns
        self.currentHeading = 0.0
        self.cmdPub = self.create_publisher(Twist, self.ns +'/cmd_vel', 10)
        self.odom_subscriber = self.create_subscription(
			Odometry, self.ns +"/odom", self.odom_callback, 10)

    def odom_callback(self,msg):
        """subscribe to odometry"""	
        qx = msg.pose.pose.orientation.x
        qy = msg.pose.pose.orientation.y
        qz = msg.pose.pose.orientation.z
        qw = msg.pose.pose.orientation.w

        roll,pitch,yaw = quaternion_tools.euler_from_quaternion(qx, qy, qz, qw)

        self.currentHeading = yaw*180/pi #conversion to degrees...

    def publishHeading(self,AngVelCMD):
        #if abs(AngVelCMD) > 0.15:#enforce max speed
            #AngVelCMD = abs(AngVelCMD)*0.15/(AngVelCMD)
            #skipping the max speed because PID won't really overshoot at such a slow speed...
        msg = Twist()
        msg.angular.z = AngVelCMD
        msg.linear.x = 0.15
        self.cmdPub.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    headingNode = setHeading()
    setPoint = 180.
    dt = rclpy.time.Duration(seconds=0.010)
    PID = PIDSignal.PIDSignal(.05,0.00,0.0015,0.01)
    #using (-)gains to enforce a direction preference
    while rclpy.ok:
        rclpy.spin_once(headingNode)
        ###NEED TO UPDATE THE PID CALLS, IT NOW TAKES ERROR AS AN ARGUMENT INSTEAD OF CURRENT,DESIRED
        while 1.02*setPoint <= headingNode.currentHeading or headingNode.currentHeading<= .98*setPoint:
            print(headingNode.currentHeading)
            rclpy.spin_once(headingNode)
            yawVelCMD = float(PID.computeSignal(setPoint,headingNode.currentHeading))
            headingNode.publishHeading(yawVelCMD)
            #block for dt...may not be the best for callbacks.. keep dt low..
            start = headingNode.get_clock().now()
            while headingNode.get_clock().now() - start < dt:
                pass
        headingNode.publishHeading(0.0)#full stop once close enough...
        print(headingNode.currentHeading)
    #note...the loop runs again in the rclpy.ok loop to ensure it hasn't drifted past

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    headingNode.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
