class PIDSignal():
    def __init__(self,kp,ki,kd,dt):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.error = [0,0] #store current and previous error
        self.dt = dt
        self.i = 0
    
    def computeSignal(self, desired,actual)->float:
        self.error[0] = self.error[1]#shift the "current" to now be previous error
        self.error[1] = desired-actual
        p = self.kp*self.error[1]
        d = self.kd*(self.error[1] - self.error[0])/self.dt
        self.i = self.i + (sum(self.error)*self.dt)/2#use trapezoidal sum...
        i = self.ki*self.i
        return p+d+i
