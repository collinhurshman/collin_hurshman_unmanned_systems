import rclpy
from rclpy.node import Node

def blockSeconds(duration):
    duration = rclpy.time.Duration(seconds=duration)#convert duration in seconds to a duration object
    start = self.get_clock().now()#get the current time 
    while self.get_clock().now() - start < duration:#evaluate change in time
        pass#do nothing while waiting for enough time to elapse

def getTimeInSeconds(nodeInstance:Node):
    return nodeInstance.get_clock().now().nanoseconds /1E9