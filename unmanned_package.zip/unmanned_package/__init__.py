def print_hello():
    print("Hello World")